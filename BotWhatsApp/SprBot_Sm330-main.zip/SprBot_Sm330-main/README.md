## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> FEITO E TRADUZIDO POR: DARK YT
<p align="center">
<img src="https://media.giphy.com/media/JROB2yZw89dFXrPXR9/giphy.gif" width="230" height="230"/>
</p>
<br>


 
</details>

### Atencion!! TRADUCIDO POR SAMU330
¿QUIERES VOLVER A CARGAR EL SCRIPT? AMO MI NOMBRE / ENLACE CHANEL .... NO CAMBIE LA INFORMACIÓN !!!

## NOTA:>
NO VENDE / COMPRE GUIÓN, ESTE GUIÓN ES 100% GRATIS PARA LOS USUARIOS DE TERMUX
</div>

### HERRAMIENTAS Y MATERIALES <img src = "https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width = "29px">
Prepare herramientas y materiales.
bash
> 2 teléfonos móviles (1 para ejecutar SC, 1 para escanear el código QR sis)
> red de Internet rápida, cuota +
> almacenamiento adecuado
> aplicación whatsapp
> aplicación termux
> café + cigarrillos KKKK; -;
''
INSTALACIÓN:

> Si no tiene el APK de Termux, descárguelo de Playstore
> ingrese el termux apk y escriba a continuación!
> termux-setup-storage
> pkg install git && pkg install tesseract && pkg install wget && pkg install ffmpeg && pkg install nodejs
> update apt && update apt
> git clone https://github.com/HigorOlive/d4rk
> cd d4rk
> npm i -g cwebp && npm i node-tesseract-ocr && npm i -g ytdl && npm i && npm i got && node index.js
> Simplemente escanee el código qr y ... listo
''

## CARACTERÍSTICAS  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="29px">

| SAMUBOT      |                   Característica        |
| :-----------: | :------------------------------: |
|       ✅       | Criador de adesivos                  |
|       ✅       | Nulis                            |
|       ✅       | Covid (Novo)                      |
|       ✅       | Alay (novo)                       |
|       ✅       | Letras (novo)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Fotos de menina / menino (Novo)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nome (Novo)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Casal (Novo)                   |
|       ✅       | Oração (Novo )                    |
|       ✅       | Google Voice (fix)               |
|       ✅       | Alcorão                            |
|       ✅       | Downloader MP3 do Youtube           |
|       ✅       | Downloader Instagram              |
|       ✅       | Twitter Downloader               |
|       ✅       | Downloader do Facebook              |
|       ✅       | Downloader TikTok (novo)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Tóxico (Novo)                      |
|       ✅       | loli                             |
|       ✅       | hentai                           |
|       ✅       | Proprietário (novo)                      |
|       ✅       | disse o sábio                       |
|       ✅       | Facto                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Doar                           |
|       ✅       | 18+.                             |
|       ✅       | MAIS recursos em breve 🍂        |

SAMU330 DOMINA 🐦❤️

<img src="https://scontent.fmid4-1.fna.fbcdn.net/v/t1.0-0/c0.4.480.480a/s526x395/103469528_154803396087710_914979189346976214_n.jpg?_nc_cat=105&ccb=2&_nc_sid=09cbfe&_nc_eui2=AeH6aagqAsn6T-BjWoA7MHDXU3lPJA6SwrxTeU8kDpLCvDTL1FWk8WJk_fN1Rqpv1GV48g1i_b9jMktxWqcHo9Y_&_nc_ohc=Ypqe--e3FZIAX_D18qc&_nc_ht=scontent.fmid4-1.fna&tp=28&oh=ba6e218586d63ee9771bfb3bb58b0d27&oe=6008A584" alt="Samu330" width="300" />


